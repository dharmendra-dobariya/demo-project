package com.care.demoapplication.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

import java.io.Serializable;
import java.util.List;
import java.util.Map;

import org.springframework.context.annotation.Bean;

@JsonIgnoreProperties(ignoreUnknown = true)
public class Weather implements Serializable {

	private static final long serialVersionUID = 7406210628182440902L;
	
	private String weatherDescription;
	private double lon;
	private String name;
	private double lat;
	private double temp;
	private double feelsLike;
	private double tempMin;
	private double tempMax;
	private int humidity;
	
	@Bean
	public Weather weather() {
		return new Weather();
	}
	
	public Weather() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Weather(Weather weather) {
		// TODO Auto-generated constructor stub
	}

	public double getLat() {
		return lat;
	}

	@JsonProperty("lat")
	public void setLat(double lat) {
		this.lat = lat;
	}
	
	public double getLon() {
		return lon;
	}

	@JsonProperty("lon")
	public void setLon(double lon) {
		this.lon = lon;
	}

	
	public String getName() {
		return name;
	}
	
	@JsonProperty("name")
	public void setName(String name) {
		this.name = name;
	}

	public String getWeatherDescription() {
		return weatherDescription;
	}

	public void setWeatherDescription(String weatherDescription) {
		this.weatherDescription = weatherDescription;
	}

	@JsonProperty("weather")
	public void setWeather(List<Map<String, Object>> weatherEntries) {
		Map<String, Object> weather = weatherEntries.get(0);
		setWeatherDescription((String) weather.get("description"));
	}

	@JsonProperty("temp")
	public double getTemp() {
		return temp;
	}

	@JsonProperty("temp")
	public void setTemp(double temp) {
		this.temp = temp;
	}
	
	@JsonProperty("feels_like")
	public double getfeelsLike() {
		return feelsLike;
	}

	@JsonProperty("feels_like")
	public void setfeelsLike(double feelsLike) {
		this.feelsLike = feelsLike;
	}
	
	@JsonProperty("temp_min")
	public double gettempMin() {
		return tempMin;
	}

	@JsonProperty("temp_min")
	public void settempMin(double tempMin) {
		this.tempMin = tempMin;
	}
	
	@JsonProperty("temp_max")
	public double gettempMax() {
		return tempMax;
	}

	@JsonProperty("temp_max")
	public void settempMax(double tempMax) {
		this.tempMax = tempMax;
	}
	
	@JsonProperty("humidity")
	public int getHumidity() {
		return humidity;
	}

	@JsonProperty("humidity")
	public void setHumidity(int humidity) {
		this.humidity = humidity;
	}
	
	@JsonProperty("coord")
	public void setCoord(Map<String, Object> coord) {
		setLon((double) coord.get("lon"));
		setLat((double) coord.get("lat"));
		
	}
	
	@JsonProperty("main")
	public void setMain(Map<String, Object> main) {
		setTemp((double) main.get("temp"));
		setfeelsLike((double) main.get("feels_like"));
		settempMin((double) main.get("temp_min"));
		settempMax((double) main.get("temp_max"));
		setHumidity((int) main.get("humidity"));
	}	
}
