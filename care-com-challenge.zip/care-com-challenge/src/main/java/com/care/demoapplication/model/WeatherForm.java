package com.care.demoapplication.model;

public class WeatherForm {
	
	private String city;

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public WeatherForm(String city) {
		super();
		this.city = city;
	}

	public WeatherForm() {
		super();
	}
}
