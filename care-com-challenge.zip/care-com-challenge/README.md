# Spring Boot openweathermap API (http://openweathermap.org/current)

## Prerequisites
 * JDK 1.8.X
 * Maven 3.5.X
 * Open weather map API keys
  
## Generating keys
 * Visit https://openweathermap.org/appid
 * SignUp, Select the package and generate API keys
  
## Run 
 * Download/Clone the project on to your local machine
 * Run the project on your machine
 * Send a request to http://localhost:8082/weather on your browser
 